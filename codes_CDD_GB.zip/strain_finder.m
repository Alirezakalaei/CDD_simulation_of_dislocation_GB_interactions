 function [strain]=strain_finder(strain,QQ,V,b_vec,n_vec,dt,dx,J, b)
num=size(QQ,3);
% s_vec=b_vec;
% e_vec=cross(n_vec,b_vec);
b_diad_n=(kron(b_vec.',n_vec)+kron(n_vec.',b_vec))/2;
n_site=size(QQ,1)*size(QQ,2);
for i=1:size(QQ,1)
    for j=1:size(QQ,2)
    gx = 0;
    gy = 0;
         for k = 1:size(QQ,3)
        
           if (i==1 || i==size(QQ,1) || j==1 || j==size(QQ,1))% && (J(i,j,k,1)+J(i,j,k,2))< QQ(i,j,k)*V(i,j)
                % horisontal and vertical flux cannot be larger than the density 
                gx = gx +J(i,j,k,1);
                gy = gy +J(i,j,k,2);
                
            else
        
                gx = gx + QQ(i,j,k)*cos(2*k*pi/num);   % i (horizontal) axis is the screw axis (reference for dislocation character)
                gy = gy + QQ(i,j,k)*sin(2*k*pi/num);
           end
         end
            GND=sqrt(gx^2+gy^2);
            flux=GND*V(i,j);
            strain_rate = b*b_diad_n*flux/(n_site);
            strain = strain + strain_rate*dt;
            
          

    end


end
%%discourse function that presents the distance of dislocation line to the nodes into density.
function [Q, theta] = discoarse1(distance,t_a,sdev,x,line,dtheta,Q, dx)
% This function obtains the density according to the distance of nodes to a dislocation line in the form of Z, a 2D matrix.
% reshape t_a (a vector size(x)^2 long for the meshpoints) into a size(x) by size (x) matrix
    h_a=reshape(t_a.',[size(x,2),size(x,2)]); 
% reshape distance (a vector size(x)^2 long for the meshpoints) into a size(x) by size (x) matrix
    distance=reshape(distance.',[size(x,2),size(x,2)]);
% Z is the gaussian profile of the dislocation line over the meshpoint space; since distance is a size(x) by size(x) matrix, so is Z
    Z=(1/(sdev*sqrt(2*pi)))*exp(-1*((distance).^2)/(2*sdev^2));
% setting the NaN elements of Z to zero
    Z(isnan(Z))=0; 
    Z=Z/dx;
% t is cumulative sum of squares of differences of successive points in “line”
    t = cumsum([0;((diff(line.').^2)*ones(2,1)).^(1/4)]).';
% derivative of curve
    derivation=fnder(cscvn(line));  
    Q=iter1(Z,t,derivation,Q,h_a);
% setting theta(k)
theta = dtheta*(1:1:size(Q,3));  % theta (dislocation character from XX axis) increases from ~0 to 2*pi as k increases from 1 to size(Q,3).
end

function [Q]=iter1(Z,t,derivation,Q,h_a)
% This function converts Z into Q that is a 3D matrix for the density over spatial and theta-space.
    for p=1:size(h_a,1)     % here, size(h_a,1) is just size(x)
        for l=1:size(h_a,2)   % here, size(h_a,2) is just size(x); (p,l) are indices over the meshpoints
        if ~isnan(h_a(p,l))  % if h_a(p,l) is not NaN
         if h_a(p,l)>1
             h_a(p,l)=1;  % h_a is fractional arc length to closest point, thus this caps any > 1 to 1
         end
            index = find((t/t(end))>=(h_a(p,l)), 1, 'first');
            if index==1
                tangent=[-dot(derivation.coefs((2*index)-1,:),[0,0,1]),dot(derivation.coefs((2*index),:),[0,0,1])];
            elseif ~isempty(index)
                t0=(h_a(p,l)*t(end))- t(index-1);
                tangent=[-dot(derivation.coefs((2*index)-3,:),[t0^2,t0^1,1]),dot(derivation.coefs((2*index)-2,:),[t0^2,t0^1,1])];
            end
            theta=2*pi-tan2thet(tangent); % theta (0 to 2*pi) is dislocation line inclination angle from XX axis
            if (floor(theta/(2*pi/size(Q,3))))+1>size(Q,3)
              Q(l,p,1)=Q(l,p,1)+ Z(p,l); % l,p corrected on Q so i is horizontal axis and j vertical
            else
            Q(l,p,(floor(theta/(2*pi/size(Q,3))))+1)=Q(l,p,(floor(theta/(2*pi/size(Q,3))))+1)+ Z(p,l); % l,p corrected on Q so i is horizontal axis and j vertical
            end
         end
        end
    end
end

function theta=tan2thet(tangent)
% This function converts sin and cos into theta, which is in the range of 0 to 2*pi
             if tangent(1,1)>=0&& tangent(1,2)>=0  % first quadrant
                theta=atan(tangent(1,2)/tangent(1,1));
            elseif tangent(1,2)>=0&& tangent(1,1)<=0   % second quadrant
                theta=atan(tangent(1,2)/tangent(1,1))+pi;
            elseif tangent(1,2)<=0&& tangent(1,1)<=0    % third quadrant
                theta=atan(tangent(1,2)/tangent(1,1))+pi;
             elseif tangent(1,2)<=0&& tangent(1,1)>=0 % fourth quadrant
                theta=atan(tangent(1,2)/tangent(1,1))+2*pi;
             end
end
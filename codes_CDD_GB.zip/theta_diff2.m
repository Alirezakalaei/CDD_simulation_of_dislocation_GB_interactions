function [dVbydxi]=theta_diff2(Q,V,rho_min,theta,dx,dy)
dVbydxi=zeros(size(Q,1),size(Q,2),size(Q,3));
xi = zeros(size(theta,2),2); 
xi(:,1) = cos(theta(:));  
xi(:,2) = sin(theta(:));
% for j=2:size(Q,2)-1
%     i=size(Q,1);
%     dVbydxi(i,j,:)=(((V(1,j)-V(i-1,j))/(2*dx))*xi(:,1))+(((V(i,j+1)-V(i,j-1))/(2*dy))*xi(:,2));
%     i=1;
%     dVbydxi(i,j,:)=(((V(i+1,j)-V(size(Q,1),j))/(2*dx))*xi(:,1))+(((V(i,j+1)-V(i,j-1))/(2*dy))*xi(:,2));
% end
% for i=2:size(Q,1)-1
%     j=1;
%     dVbydxi(i,j,:)=(((V(i+1,j)-V(i-1,j))/(2*dx))*xi(:,1))+(((V(i,j+1)-V(i,size(Q,2)))/(2*dy))*xi(:,2));
%     j=size(Q,2);
%     dVbydxi(i,j,:)=(((V(i+1,j)-V(i-1,j))/(2*dx))*xi(:,1))+(((V(i,1)-V(i,j-1))/(2*dy))*xi(:,2));
% end
% i=1;j=1;
% dVbydxi(i,j,:)=(((V(i+1,j)-V(size(Q,1),j))/(2*dx))*xi(:,1))+(((V(i,j+1)-V(i,size(Q,2)))/(2*dy))*xi(:,2));
% i=size(Q,1);j=1;
% dVbydxi(i,j,:)=(((V(1,j)-V(i-1,j))/(2*dx))*xi(:,1))+(((V(i,j+1)-V(i,size(Q,2)))/(2*dy))*xi(:,2));
% i=size(Q,1);j=size(Q,2);
% dVbydxi(i,j,:)=(((V(1,j)-V(i-1,j))/(2*dx))*xi(:,1))+(((V(i,1)-V(i,j-1))/(2*dy))*xi(:,2));
% i=1;j=size(Q,2);
% dVbydxi(i,j,:)=(((V(i+1,j)-V(size(Q,1),j))/(2*dx))*xi(:,1))+(((V(i,1)-V(i,j-1))/(2*dy))*xi(:,2));



 for i=1:size(Q,1)
    for j=1:size(Q,2)
        px=size(Q,1)-1; py=size(Q,2)-1;
     [GV]=mirror_2d(V, size(V,1), size(V,2), 1, px, py);
        if sum(Q(i,j,:),3)<=rho_min
              continue
        end
        dVbydxi(i,j,:)=(((GV(px+i+1,py+j)-GV(px+i-1,py+j))/(2*dx))*xi(:,1))+(((GV(px+i,py+j+1)-GV(px+i,py+j-1))/(2*dy))*xi(:,2));
    end
 end
end


function [interaction_mat] = grain_point_interaction(interaction_dist,interaction_STD,magnitude,dx,N)
%here this fucntion specifies the distance between interaction points on
%the grain boundary.
interaction_mat=zeros(1,3*N); % this matrix will be multiplied into the flux passsing via the grain boundary.
points=linspace(-1*magnitude,2*magnitude,3*N);
interaction_points=-1*magnitude:interaction_dist:2*magnitude;
for i=1:size(interaction_points,2)
    interaction_mat=interaction_mat+((normpdf(points,interaction_points(i),interaction_STD))/sum(normpdf(points,interaction_points(i),interaction_STD),'all'));
end
interaction_mat=interaction_mat(N+1:2*N);
end
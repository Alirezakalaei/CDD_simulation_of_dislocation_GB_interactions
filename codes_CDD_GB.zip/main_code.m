clc
clear 
close all
tic

% The higher strain is .0001, and the medium strain rate is chosen to be
% .00005 and the low one is .00001.
% This code is for specifying the size effect on the intergranular slip transfer.

load('initial_dislocation_8000b.mat')

factor_values = linspace(pi/80, pi/2, 25);
N = size(factor_values, 2);
converter = zeros(1, N);
coef1 = zeros(1, N);
coef2 = coef1;
n_factor = zeros(1, 3 * N);
strains = cell(1, N);
sum_JJ = cell(1, N);

% Start a parallel pool
parpool(80)

V_all = cell(1, N);
stresses = V_all;
anni_amount = V_all; 
nuc_amount = V_all;
strain_tensor = V_all;
RSS = V_all;
effective_strain = V_all;
strain_list = V_all;

% Loop over the factor values and run the program in parallel
parfor ii = 1:N 
    % Call your program with the current factor value (rot_theta)
    [stresses{ii}, strains{ii}, sum_JJ{ii}, coef1(ii), coef2(ii), V_all{ii}, ...
     strain_tensor{ii}, converter(ii), anni_amount{ii}, nuc_amount{ii}, ...
     RSS{ii}, effective_strain{ii}, strain_list{ii}] = DDFD_single_plane(factor_values(ii), lines); 
end

strains_p = zeros(3, N);
strains_J = zeros(1, N);
stresses_P = zeros(3, N);
strains_al = zeros(1, N);

for i = 1:N
    for j = 1:3
        stresses_P(j, i) = stresses_P(j, i) + stresses{i}{j}(end);
        strains_p(j, i) = strains_p(j, i) + strains{i}{j}(end);
        strains_J(1, i) = sum_JJ{i}(1, end);
    end
    
    strain_a = strain_tensor{i}{1} + strain_tensor{i}{2} + strain_tensor{i}{3};
    strains_al(i) = (sqrt(2)/3) * sqrt((strain_a(1,1) - strain_a(2,2))^2 + ...
                    (strain_a(3,3) - strain_a(2,2))^2 + (strain_a(1,1) - strain_a(3,3))^2 ...
                    + 1.5 * (strain_a(1,3)^2 + strain_a(2,3)^2 + strain_a(1,2)^2));
end

save('result_summary_little_lower_strain')

%% Plotting Misorientation Angles
figure
mis_angle = [.055529, .14565, .23548, .67316, 1.0697, 1.3831, 1.5546];
ii = 0;

for i = [1, 2, 3:5:25]
    hold on
    ii = ii + 1;
    name = ['misorientation Ang. = ', '\fontsize{8}', num2str(mis_angle(ii))];
    plot(effective_strain{i}, RSS{i}{1} / 5000, '-o', "DisplayName", name);
    xlabel("strain(%)")
    ylabel("Applied stress (\mu)")
end

lgn = legend;
lgn.FontSize = 8;
drawnow

toc

%% Strain-Stress Plot 
% Define the misorientation angles indices and corresponding radians
angles = [1, 2, 5, 10, 15, 20, 25]; % indices of the desired misorientation angles
factor_values = linspace(pi/80, pi/2, 25); % Calculate factor values for radians

% Number of plots
num_plots = numel(angles);

% Create a color matrix using a colormap
cm = colormap(jet(num_plots));  % Generates a jet colormap with 'num_plots' colors

% Create a figure
figure;
hold on; 

% Loop over the desired angles and plot each stress-strain curve
for i = 1:num_plots
    angle_index = angles(i);
    strain_percent = 100 * strains{angle_index}{2}; 
    normalized_stress = RSS{angle_index}{2} / (26e9 * .41);
    plot(strain_percent, normalized_stress, 'DisplayName', ...
        sprintf('%.2f radians', factor_values(angle_index)), 'Color', cm(i, :));
end

% Formatting the plot with strain rate in the title
strain_rate = 0.00005; % Define the strain rate value
dt = 1; % Define the value of dt if necessary
xlabel('Strain (%)', 'FontSize', 12);
ylabel('Stress/\mu', 'FontSize', 12);
title('Stress--Strain Curves at a Strain Rate of $5 \times 10^{-5}/dt$', ...
    'FontSize', 12, 'Interpreter', 'latex');

legend('show', 'Location', 'northeast');
grid on; 
set(gca, 'FontSize', 12); 
hold off; 

%% Yield Stress Plotting
% Define the misorientation angles indices and corresponding radians
angles = 1:25; % indices of the desired misorientation angles
factor_values = linspace(pi/80, pi/2, 25); % Calculate factor values for radians

% Array to hold yield stress values
yield_stresses = zeros(1, numel(angles));

% Loop over the desired angles to extract yield stress
for i = 1:numel(angles)
    angle_index = angles(i);
    % Yield stress is assumed to be the 40th stress value in the normalized RSS array
    yield_stress = RSS{angle_index}{2}(40) / (26e9 * .41); 
    yield_stresses(i) = yield_stress;
end
yield1 = yield_stresses;

% Create a clean journal-style plot of yield stress vs. misorientation angle
figure;
hold on;

% Plotting both strain rate cases (Note: yield2 must be defined elsewhere in your workspace)
plot(factor_values(angles), yield1, '-o', ...
    'LineWidth', 1.5, 'MarkerSize', 6, 'DisplayName', ...
    '$\it{Strain~rate:~}5 \times 10^{-5}/\Delta t$');

% Assuming yield2 is loaded or defined prior to this in your full environment
plot(factor_values(angles), yield2, '-s', ...
    'LineWidth', 1.5, 'MarkerSize', 6, 'DisplayName', ...
    '$\it{Strain~rate:~}1 \times 10^{-4}/\Delta t$');

% Axis labels with italicized physical quantities
% (Note: The second ylabel overwrites the first one in MATLAB)
ylabel('Yield stress, $\it{\sigma}_{[100]}/\mu$', 'FontSize', 12, 'Interpreter', 'latex');
ylabel('Yield stress/$\mu$', 'FontSize', 12, 'Interpreter', 'latex');

% Title
title('Yield Stress vs. Misorientation Angle', ...
    'FontSize', 13, 'Interpreter', 'latex');

% Legend
legend('Interpreter', 'latex', 'Location', 'northeast');

% Grid and styling
grid on;
set(gca, 'FontSize', 12, 'TickLabelInterpreter', 'latex');

hold off;
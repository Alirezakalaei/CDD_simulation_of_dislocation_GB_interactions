function [nodes,vel_modifier,disf] = vel_modifier(XX,YY,ZZ,N,cut_off_dis,g_val)
      nodes=[XX(1,1) XX(1,end);YY(1,1)+cut_off_dis YY(1,end)-cut_off_dis];
      theta=linspace(pi,pi/2,20);
      radii=[(XX(1,end)+cut_off_dis)+cut_off_dis*cos(theta);
      (YY(1,end)-cut_off_dis)+cut_off_dis*sin(theta)];
      nodes=[nodes,radii];

      nodes=[nodes,[XX(end,end)-cut_off_dis;YY(end,end)]];
      theta=linspace(pi/2,0,20);
      radii=[(XX(end,end)-cut_off_dis)+cut_off_dis*cos(theta);
      (YY(end,end)-cut_off_dis)+cut_off_dis*sin(theta)];
      nodes=[nodes,radii];
% 
      nodes=[nodes,[XX(end,1);YY(end,1)+cut_off_dis]];
      theta=linspace(0,-pi/2,20);
      radii=[(XX(end,1)-cut_off_dis)+cut_off_dis*cos(theta);
      (YY(end,1)+cut_off_dis)+cut_off_dis*sin(theta)];
      nodes=[nodes,radii];
% 
% 
      nodes=[nodes,[XX(1,1)+cut_off_dis;YY(1,1)]];
      theta=linspace(-pi/2,-pi,20);
      radii=[(XX(1,1)+cut_off_dis)+cut_off_dis*cos(theta);
      (YY(1,1)+cut_off_dis)+cut_off_dis*sin(theta)];
      nodes=[nodes,radii];
 %     nodes{i,j}=[nodes{i,j},[XX{i,j}(1,1) ;YY{i,j}(1,1)+cut_off_dis]];
% 
      Z=zeros(1,size(nodes,2));
      nodes=[nodes;Z];


%     nodes{i,j}=[XX{i,j}(1,1),XX{i,j}(1,end),XX{i,j}(end,end),XX{i,j}(end,1),XX{i,j}(1,1);YY{i,j}(1,1),YY{i,j}(1,end),,YY{i,j}(end,end),YY{i,j}(end,1),YY{i,j}(1,1);ZZ{i,j}(1,1),ZZ{i,j}(1,end),ZZ{i,j}(end,end),ZZ{i,j}(end,1),ZZ{i,j}(1,1)];


   meshpoints=zeros(N^2,3);
   meshpoints(:,1)=reshape(XX,1,[]);
   meshpoints(:,2)=reshape(YY,1,[]);
   meshpoints(:,3)=reshape(ZZ,1,[]);

    [~,distance,~]=distance2curve(nodes.',meshpoints,'linear');
    distance=reshape(distance.',[N,N]);
    distance(distance>cut_off_dis)=NaN;
    disf=distance;
    b=2*(-g_val+1)/cut_off_dis;
    a=-b/(2*cut_off_dis);
    distance=(a*(distance.^2))+(b*distance)+g_val;
    distance(isnan(distance))=1;
    vel_modifier=distance;
    in=inpolygon(reshape(XX,1,[]),reshape(YY,1,[]),nodes(1,:),nodes(2,:));
    out_nodes=find(~in);
    if size(out_nodes,2)>0
    for o=1:size(out_nodes,2)
        i_index=floor((out_nodes(o)-1)/N)+1;
        j_index=rem(out_nodes(o)-1,N)+1;
        vel_modifier(i_index,j_index)=g_val;
        disf(i_index,j_index)=0;
   

    end
    end
end
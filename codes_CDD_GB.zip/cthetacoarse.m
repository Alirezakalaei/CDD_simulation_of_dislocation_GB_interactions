function QQ = cthetacoarse(Q, dtheta, P)
    % This function converts Q into QQ that is Gaussian distributed over theta-space.
    
    % Get dimensions
    [dim1, dim2, dim3] = size(Q);
    QQ = zeros(dim1, dim2, dim3); % Initialize QQ with zeros

    % Precompute normalization factor using the formula for the PDF of the normal distribution
    norm_factor = 1 / (P * sqrt(2 * pi));

    % Loop through Q
    for i = 1:dim1
        for j = 1:dim2
            for k = 1:dim3
                if Q(i,j,k) ~= 0
                    for l = round(-0.5 * dim3) : round(0.5 * dim3)
                        distance = abs(l) * dtheta;
                        if distance < 5 * P
                            % Compute weight using the PDF formula and normalize
                            weight = (1 / (P * sqrt(2 * pi))) * exp(-0.5 * (distance^2 / P^2)) / norm_factor;
                            new_index = mod(k + l - 1, dim3) + 1; % Ensures valid index in [1, dim3]
                            QQ(i, j, new_index) = QQ(i, j, new_index) + (Q(i, j, k) * weight);
                        end
                    end
                end
            end
        end
    end
end



% function [am]=amount(distance,P,dtheta)
% % The amount of density according to the difference between θ, arbitrary character, and θi, dislocation character.
% if distance<=5*P
%    am=(dtheta/(P*sqrt(2*pi)))*exp(-(distance)^2/(2*(P^2)));%this gives us the whole density residing(integrated one).
% else
%    am=0;
% end
% end

 
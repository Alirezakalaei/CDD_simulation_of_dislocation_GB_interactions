function [tau_all1,tau_all2,b_vec,b_vec2,n_vec,coef1,coef2] = tau_calculator1(tau,b_vec1,n_vec1,b,k_par,border_lines,rot_thet)
% this section is for calculating RSS on every slip system.

b_vec=cell(1,9);%9 is the number of involved slip systems
n_vec=b_vec;
tau_all1=b_vec;
combinations=nchoosek(1:9,4);
coef1=zeros(9,9);
coef2=coef1;
[b_vec2,n_vec2,b_vec4,n_vec4] = burgers_maker(b_vec1,n_vec1,rot_thet,border_lines{1,1},border_lines{1,2});
%for the first slip plane;
for i=1:size(b_vec1,2)
    tauu=sum(kron(b_vec1{i}.',n_vec1).*tau,'all');
    % b_vec{i}=sign(tauu+.000001)*b_vec1{i};
    % tau_all1{i}=abs(tauu);
    b_vec{i}=b_vec1{i};
    if tauu<0
      tau_all1{i}=0;
    else
        tau_all1{i}=tauu;
    end
    n_vec{i}=n_vec1;
    
end
% for the second slip plane
for i=1:size(b_vec2,2)
    tauu=sum(kron(b_vec2{i}.',n_vec2).*tau,'all');
    % b_vec{size(b_vec1,2)+i}=sign(tauu+.000001)*b_vec2{i};
    % tau_all1{size(b_vec1,2)+i}=abs(tauu);
       b_vec{size(b_vec1,2)+i}=b_vec2{i};

     if tauu<0
        tau_all1{size(b_vec1,2)+i}=0;
     else
        tau_all1{size(b_vec1,2)+i}=tauu;
    end
    n_vec{size(b_vec1,2)+i}=n_vec2;

end

    for i=1:size(b_vec4,2)
    tauu=sum(kron(b_vec4{i}.',n_vec4).*tau,'all');
    b_vec{size(b_vec1,2)+size(b_vec2,2)+i}=b_vec4{i};
    % tau_all1{size(b_vec1,2)+size(b_vec2,2)+1}=abs(tauu);
    if tauu<0
        tau_all1{size(b_vec1,2)+size(b_vec2,2)+i}=0;
    else
        tau_all1{size(b_vec1,2)+size(b_vec2,2)+i}=tauu;
    end
        n_vec{size(b_vec1,2)+size(b_vec2,2)+i}=n_vec4;

    end

% this section is for finding the coefcient seciton of dislocation density
% transfer
devision_bott=(dot(b_vec{1},cross(b_vec{4},b_vec{5})))^2;
for i=1:size(combinations,1)
  if isempty(find(combinations(i,:)==0, 1)) && isempty(find(combinations(i,:)==0, 1)) && isempty(find(combinations(i,:)==0, 1)) && isempty(find(combinations(i,:)==0, 1)) && isempty(find(combinations(i,:)==0, 1))
      b1=b_vec{combinations(i,1)};b2=b_vec{combinations(i,2)};b3=b_vec{combinations(i,3)};b4=b_vec{combinations(i,4)};
      C=sym([dot(b2,cross(b3,b4)), dot(b3,cross(b1,b4)) dot(b1,cross(b2,b4)), dot(b1,cross(b3,b2)) ]);
      % C(abs(C)<10^-10)=0;
      C_diad=kron(C.',C);
    % C_diad=[(dot(b_vec2{1,j},n_vec4))^2 dot(b_vec2{1,j},n_vec4)*dot(b_vec4{i,j},n_vec1) (dot(b_vec1{1,i},n_vec2)*dot(b_vec2{1,j},n_vec4));...
    %     dot(b_vec2{1,j},n_vec4)*dot(b_vec4{i,j},n_vec1) (dot(b_vec4{i,j},n_vec1))^2 dot(b_vec4{i,j},n_vec1)*dot(b_vec1{1,i},n_vec2);...
    %     (dot(b_vec1{1,i},n_vec2)*dot(b_vec2{1,j},n_vec4)) dot(b_vec4{i,j},n_vec1)*dot(b_vec1{1,i},n_vec2) (dot(b_vec1{1,i},n_vec2))^2];
   %L=k_par;%./sym([C_diad(1,1),C_diad(1,1),C_diad(1,1) C_diad(1,1);C_diad(2,2),C_diad(2,2),C_diad(2,2),C_diad(2,2);C_diad(3,3),C_diad(3,3),C_diad(3,3),C_diad(3,3);C_diad(3,3),C_diad(3,3),C_diad(3,3),C_diad(3,3) ]);
  L=k_par/sym(devision_bott); 
  B=[b 0 0 0;0 b 0 0;0 0 b 0;0 0 0 b];
   T=[tau_all1{combinations(i,1)} 0 0 0;0 tau_all1{combinations(i,2)} 0 0;0 0 tau_all1{combinations(i,3)} 0;0 0 0 tau_all1{combinations(i,4)}];
    coef_one=double(L.*(B^-1)*C_diad*B*T);
    % coef_one(isnan(coef_one)| abs(coef_one)<10^-15)=0;
    for n=1:size(coef_one,1)
        for m=1:size(coef_one,2)     
        coef1(combinations(i,n),combinations(i,m))=coef1(combinations(i,n),combinations(i,m))+coef_one(n,m);       
        end
    end
      end
    
end

%%

% the coef calculation for two other grain sides
[b_vec22,n_vec22,b_vec44,n_vec44] = burgers_maker(b_vec1,n_vec1,rot_thet,border_lines{1,2},border_lines{1,1});
%for the first slip plane;
b_vec=cell(1,9); %9 is the number of involved slip systems
n_vec=b_vec;
tau_all2=b_vec;
for i=1:size(b_vec1,2)
    tauu=sum(kron(b_vec1{i}.',n_vec1).*tau,'all');
    % b_vec{i}=sign(tauu+.000001)*b_vec1{i};
    % tau_all2{i}=abs(tauu);
    % n_vec{i}=n_vec1;
    b_vec{i}=b_vec1{i};
    if tauu<=0
      tau_all2{i}=0;
    else
        tau_all2{i}=tauu;
    end
    n_vec{i}=n_vec1;
    
end

% for the second slip plane
for i=1:size(b_vec22,2)
    tauu=sum(kron(b_vec22{i}.',n_vec22).*tau,'all');
    % b_vec{size(b_vec1,2)+i}=sign(tauu+.000001)*b_vec22{i};
    % tau_all2{size(b_vec1,2)+i}=abs(tauu);
    % n_vec{size(b_vec1,2)+i}=n_vec22;
      b_vec{size(b_vec1,2)+i}=b_vec22{i};

     if tauu<0
        tau_all2{size(b_vec1,2)+i}=0;
     else
        tau_all2{size(b_vec1,2)+i}=tauu;
    end
    n_vec{size(b_vec1,2)+i}=n_vec22;

end

    for i=1:size(b_vec44,2)
    tauu=sum(kron(b_vec44{i}.',n_vec44).*tau,'all');
    b_vec{size(b_vec1,2)+size(b_vec22,2)+i}=b_vec44{i};
    % tau_all1{size(b_vec1,2)+size(b_vec2,2)+1}=abs(tauu);
    if tauu<=0
        
        tau_all2{size(b_vec1,2)+size(b_vec22,2)+i}=0;
    else
        
        tau_all2{size(b_vec1,2)+size(b_vec22,2)+i}=tauu;
    end
        n_vec{size(b_vec1,2)+size(b_vec22,2)+i}=n_vec44;

    end
% this section is for finding the coefcient seciton of dislocation density
% transfer
devision_bott=(dot(b_vec{1},cross(b_vec{4},b_vec{5})))^2;
for i=1:size(combinations,1)
  if isempty(find(combinations(i,:)==0, 1)) && isempty(find(combinations(i,:)==0, 1)) && isempty(find(combinations(i,:)==0, 1)) && isempty(find(combinations(i,:)==0, 1)) && isempty(find(combinations(i,:)==7, 1))

      b1=b_vec{combinations(i,1)};b2=b_vec{combinations(i,2)};b3=b_vec{combinations(i,3)};b4=b_vec{combinations(i,4)};

      C=sym([dot(b2,cross(b3,b4)), dot(b3,cross(b1,b4)) dot(b1,cross(b2,b4)), dot(b1,cross(b3,b2)) ]);
 
      % C(abs(C)<10^-10)=0;
      C_diad=kron(C.',C);
    % C_diad=[(dot(b_vec2{1,j},n_vec4))^2 dot(b_vec2{1,j},n_vec4)*dot(b_vec4{i,j},n_vec1) (dot(b_vec1{1,i},n_vec2)*dot(b_vec2{1,j},n_vec4));...
    %     dot(b_vec2{1,j},n_vec4)*dot(b_vec4{i,j},n_vec1) (dot(b_vec4{i,j},n_vec1))^2 dot(b_vec4{i,j},n_vec1)*dot(b_vec1{1,i},n_vec2);...
    %     (dot(b_vec1{1,i},n_vec2)*dot(b_vec2{1,j},n_vec4)) dot(b_vec4{i,j},n_vec1)*dot(b_vec1{1,i},n_vec2) (dot(b_vec1{1,i},n_vec2))^2];
    %L=k_par./sym([C_diad(1,1),C_diad(1,1),C_diad(1,1) C_diad(1,1);C_diad(2,2),C_diad(2,2),C_diad(2,2),C_diad(2,2);C_diad(3,3),C_diad(3,3),C_diad(3,3),C_diad(3,3);C_diad(3,3),C_diad(3,3),C_diad(3,3),C_diad(3,3) ]);
    L=k_par./sym(devision_bott);
   B=[b 0 0 0;0 b 0 0;0 0 b 0;0 0 0 b];
 
   T=[tau_all2{combinations(i,1)} 0 0 0;0 tau_all2{combinations(i,2)} 0 0;0 0 tau_all2{combinations(i,3)} 0;0 0 0 tau_all2{combinations(i,4)}];
    coef_one=double(L.*(B^-1)*C_diad*B*T);
    % coef_one(isnan(coef_one)| abs(coef_one)<10^-15)=0;
    for n=1:size(coef_one,1)
        for m=1:size(coef_one,2)
        coef2(combinations(i,n),combinations(i,m))=coef2(combinations(i,n),combinations(i,m))+coef_one(n,m);       
        end
    end    
  end
end
end
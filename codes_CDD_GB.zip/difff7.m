function [F] = difff7(QQ,dt,cos_thetaV,sin_thetaV,J,Vbyds)
%this function is for the condition considering the velocity is positive
%close to the grain boundary
%UNTITLED13 Summary of this function goes here
%   Detailed explanation goes here

G=QQ;
K1=FDM(G,Vbyds,cos_thetaV,sin_thetaV,J);  %% select the method here (FEM, FDM1 to 3)

G=QQ+K1*(dt/2);
G(G<0)=0;
K2=FDM(G,Vbyds,cos_thetaV,sin_thetaV,J);

G=QQ+K2*(dt/2);
G(G<0)=0;
K3=FDM(G,Vbyds,cos_thetaV,sin_thetaV,J);

G=QQ+K3*dt;
G(G<0)=0;
K4=FDM(G,Vbyds,cos_thetaV,sin_thetaV,J);

F=QQ+((K1+(2*K2)+(2*K3)+K4)*dt)/6;
F(F<0)=0;
% F=QQ+K1*dt;  % simple FDM
end

% This one uses individual nodal theta as the flux projection angle
function [K]=FDM(G,Vbyds,cos_thetaV,sin_thetaV,J)
K=zeros(size(G,1),size(G,2),size(G,3));
px=size(G,1)-1; py=size(G,2)-1;
[G_b]=mirror_2d(G, size(G,1), size(G,2), size(G,3), px, py);
[Vbyds_b]=mirror_2d(Vbyds, size(Vbyds,1), size(Vbyds,2), 1, px, py);
%without any corner
for i=2:size(G,1)-1
    for j=2:size(G,2)-1
         for k=1:size(G,3) 
            flux_A=(G_b(i+px,j-1+py,k)*Vbyds_b(i+px,j-1+py)+G_b(i+1+px,j-1+py,k)*Vbyds_b(i+1+px,j-1+py)+G_b(i+1+px,j+py,k)*Vbyds_b(i+1+px,j+py))/4; % A
            flux_B=(G_b(i+px,j+1+py,k)*Vbyds_b(i+px,j+1+py)+G_b(i-1+px,j+1+py,k)*Vbyds_b(i-1+px,j+1+py)+G_b(i-1+px,j+py,k)*Vbyds_b(i-1+px,j+py))/4; % B
            flux_C=(G_b(i-1+px,j-1+py,k)*Vbyds_b(i-1+px,j-1+py)+G_b(i+px,j-1+py,k)*Vbyds_b(i+px,j-1+py)+G_b(i-1+px,j+py,k)*Vbyds_b(i-1+px,j+py))/4; % C
            flux_D=(G_b(i+1+px,j+1+py,k)*Vbyds_b(i+1+px,j+1+py)+G_b(i+px,j+1+py,k)*Vbyds_b(i+px,j+1+py)+G_b(i+1+px,j+py,k)*Vbyds_b(i+1+px,j+py))/4; % D
            K(i,j,k)=-((flux_B-flux_A)*sin_thetaV(k)+(flux_D-flux_C)*cos_thetaV(k));
            
            %                K(i,j,k)=(G_b_b(i+px,j+1+py,k)*Vbyds_b(i+px,j+1+py)-G_b_b(i+px,j-1+py,k)*Vbyds_b(i+px,j-1+py))*sin((2*k*pi/num)-pi/2)...
%                 +(G_b_b(i+px+1,j+py,k)*Vbyds_b(i+1+px,j+py)-G_b_b(i+px-1,j+py,k)*Vbyds_b(i+px-1,j+py))*cos((2*k*pi/num)-pi/2);
         end
    end
end
% elements on the one edge
i=1;
    for j=2:size(G,2)-1
         for k=1:size(G,3) 
            flux_A=(G_b(i+px,j-1+py,k)*Vbyds_b(i+px,j-1+py)+G_b(i+1+px,j-1+py,k)*Vbyds_b(i+1+px,j-1+py)+G_b(i+1+px,j+py,k)*Vbyds_b(i+1+px,j+py)+G_b(i+px,j+py,k)*Vbyds_b(i+px,j+py))/4; % A
            flux_B=0; % B
            flux_C=0;% C
            flux_D=(G_b(i+1+px,j+1+py,k)*Vbyds_b(i+1+px,j+1+py)+G_b(i+px,j+1+py,k)*Vbyds_b(i+px,j+1+py)+G_b(i+1+px,j+py,k)*Vbyds_b(i+1+px,j+py)+G_b(i+px,j+py,k)*Vbyds_b(i+px,j+py))/4; % D
            K(i,j,k)=-J(i,j,k,1)-J(i,j,k,2)-((flux_B-flux_A)*sin_thetaV(k)+(flux_D-flux_C)*cos_thetaV(k));            
            %                K(i,j,k)=(G_b(i+px,j+1+py,k)*Vbyds_b(i+px,j+1+py)-G_b(i+px,j-1+py,k)*Vbyds_b(i+px,j-1+py))*sin((2*k*pi/num)-pi/2)...
%                 +(G_b(i+px+1,j+py,k)*Vbyds_b(i+1+px,j+py)-G_b(i+px-1,j+py,k)*Vbyds_b(i+px-1,j+py))*cos((2*k*pi/num)-pi/2);
         end
    end

i=size(G,1);
    for j=2:size(G,2)-1
         for k=1:size(G,3) 
            flux_A=0; % A
            flux_B=(G_b(i+px,j+1+py,k)*Vbyds_b(i+px,j+1+py)+G_b(i-1+px,j+1+py,k)*Vbyds_b(i-1+px,j+1+py)+G_b(i-1+px,j+py,k)*Vbyds_b(i-1+px,j+py)+G_b(i+px,j+py,k)*Vbyds_b(i+px,j+py))/4; % B
            flux_C=(G_b(i-1+px,j-1+py,k)*Vbyds_b(i-1+px,j-1+py)+G_b(i+px,j-1+py,k)*Vbyds_b(i+px,j-1+py)+G_b(i-1+px,j+py,k)*Vbyds_b(i-1+px,j+py)+G_b(i+px,j+py,k)*Vbyds_b(i+px,j+py))/4; % C
            flux_D=0; % D
            K(i,j,k)=-J(i,j,k,1)-J(i,j,k,2)-((flux_B-flux_A)*sin_thetaV(k)+(flux_D-flux_C)*cos_thetaV(k));            
            %                K(i,j,k)=(G_b(i+px,j+1+py,k)*Vbyds_b(i+px,j+1+py)-G_b(i+px,j-1+py,k)*Vbyds_b(i+px,j-1+py))*sin((2*k*pi/num)-pi/2)...
%                 +(G_b(i+px+1,j+py,k)*Vbyds_b(i+1+px,j+py)-G_b(i+px-1,j+py,k)*Vbyds_b(i+px-1,j+py))*cos((2*k*pi/num)-pi/2);
         end
    end

j=1;
    for i=2:size(G,2)-1
         for k=1:size(G,3) 
            flux_A=0; % A
            flux_B=(G_b(i+px,j+1+py,k)*Vbyds_b(i+px,j+1+py)+G_b(i-1+px,j+1+py,k)*Vbyds_b(i-1+px,j+1+py)+G_b(i-1+px,j+py,k)*Vbyds_b(i-1+px,j+py)+G_b(i+px,j+py,k)*Vbyds_b(i+px,j+py))/4; % B
            flux_C=0; % C
            flux_D=(G_b(i+1+px,j+1+py,k)*Vbyds_b(i+1+px,j+1+py)+G_b(i+px,j+1+py,k)*Vbyds_b(i+px,j+1+py)+G_b(i+1+px,j+py,k)*Vbyds_b(i+1+px,j+py)+G_b(i+px,j+py,k)*Vbyds_b(i+px,j+py))/4; % D
            K(i,j,k)=-J(i,j,k,1)-J(i,j,k,2)-((flux_B-flux_A)*sin_thetaV(k)+(flux_D-flux_C)*cos_thetaV(k));            
            %                K(i,j,k)=(G_b(i+px,j+1+py,k)*Vbyds_b(i+px,j+1+py)-G_b(i+px,j-1+py,k)*Vbyds_b(i+px,j-1+py))*sin((2*k*pi/num)-pi/2)...
%                 +(G_b(i+px+1,j+py,k)*Vbyds_b(i+1+px,j+py)-G_b(i+px-1,j+py,k)*Vbyds_b(i+px-1,j+py))*cos((2*k*pi/num)-pi/2);
         end
    end

j=size(G,2);
    for i=2:size(G,2)-1
         for k=1:size(G,3) 
            flux_A=(G_b(i+px,j-1+py,k)*Vbyds_b(i+px,j-1+py)+G_b(i+1+px,j-1+py,k)*Vbyds_b(i+1+px,j-1+py)+G_b(i+1+px,j+py,k)*Vbyds_b(i+1+px,j+py)+G_b(i+px,j+py,k)*Vbyds_b(i+px,j+py))/4; % A
            flux_B=0; % B
            flux_C=(G_b(i-1+px,j-1+py,k)*Vbyds_b(i-1+px,j-1+py)+G_b(i+px,j-1+py,k)*Vbyds_b(i+px,j-1+py)+G_b(i-1+px,j+py,k)*Vbyds_b(i-1+px,j+py)+G_b(i+px,j+py,k)*Vbyds_b(i+px,j+py))/4; % C
            flux_D=0; % D
            K(i,j,k)=-J(i,j,k,1)-J(i,j,k,2)-((flux_B-flux_A)*sin_thetaV(k)+(flux_D-flux_C)*cos_thetaV(k));            
            %                K(i,j,k)=(G_b_b(i+px,j+1+py,k)*Vbyds_b(i+px,j+1+py)-G_b(i+px,j-1+py,k)*Vbyds_b(i+px,j-1+py))*sin((2*k*pi/num)-pi/2)...
%                 +(G_b(i+px+1,j+py,k)*Vbyds_b(i+1+px,j+py)-G_b(i+px-1,j+py,k)*Vbyds_b(i+px-1,j+py))*cos((2*k*pi/num)-pi/2);
         end
    end


% element on the corners
i=size(G,1);j=1;
 for k=1:size(G,3) 
            flux_A=0; % A
            flux_B=(G_b(i+px,j+1+py,k)*Vbyds_b(i+px,j+1+py)+G_b(i-1+px,j+1+py,k)*Vbyds_b(i-1+px,j+1+py)+G_b(i-1+px,j+py,k)*Vbyds_b(i-1+px,j+py)+G_b(i+px,j+py,k)*Vbyds_b(i+px,j+py))/4;% B
            flux_C=0;  % C
            flux_D=0; % D
            K(i,j,k)=-J(i,j,k,1)-J(i,j,k,2)-((flux_B-flux_A)*sin_thetaV(k)+(flux_D-flux_C)*cos_thetaV(k));            
            %                K(i,j,k)=(G_b(i+px,j+1+py,k)*Vbyds_b(i+px,j+1+py)-G_b(i+px,j-1+py,k)*Vbyds_b(i+px,j-1+py))*sin((2*k*pi/num)-pi/2)...
%                 +(G_b(i+px+1,j+py,k)*Vbyds_b(i+1+px,j+py)-G_b(i+px-1,j+py,k)*Vbyds_b(i+px-1,j+py))*cos((2*k*pi/num)-pi/2);
 end

i=1;j=1;
 for k=1:size(G,3) 
            flux_A=0; % A
            flux_B=0; % B
            flux_C=0; % C
            flux_D=(G_b(i+1+px,j+1+py,k)*Vbyds_b(i+1+px,j+1+py)+G_b(i+px,j+1+py,k)*Vbyds_b(i+px,j+1+py)+G_b(i+1+px,j+py,k)*Vbyds_b(i+1+px,j+py)+G_b(i+px,j+py,k)*Vbyds_b(i+px,j+py))/4; % D
            K(i,j,k)=-J(i,j,k,1)-J(i,j,k,2)-((flux_B-flux_A)*sin_thetaV(k)+(flux_D-flux_C)*cos_thetaV(k));            
            %                K(i,j,k)=(G_b(i+px,j+1+py,k)*Vbyds_b(i+px,j+1+py)-G_b(i+px,j-1+py,k)*Vbyds_b(i+px,j-1+py))*sin((2*k*pi/num)-pi/2)...
%                 +(G_b(i+px+1,j+py,k)*Vbyds_b(i+1+px,j+py)-G_b(i+px-1,j+py,k)*Vbyds_b(i+px-1,j+py))*cos((2*k*pi/num)-pi/2);
 end

i=size(G,1);j=size(G,2);
 for k=1:size(G,3) 
            flux_A=0; % A
            flux_B=0; % B
            flux_C=(G_b(i-1+px,j-1+py,k)*Vbyds_b(i-1+px,j-1+py)+G_b(i+px,j-1+py,k)*Vbyds_b(i+px,j-1+py)+G_b(i-1+px,j+py,k)*Vbyds_b(i-1+px,j+py)+G_b(i+px,j+py,k)*Vbyds_b(i+px,j+py))/4; % C
            flux_D=0; % D
            K(i,j,k)=-J(i,j,k,1)-J(i,j,k,2)-((flux_B-flux_A)*sin_thetaV(k)+(flux_D-flux_C)*cos_thetaV(k));            
            %                K(i,j,k)=(G_b(i+px,j+1+py,k)*Vbyds_b(i+px,j+1+py)-G_b(i+px,j-1+py,k)*Vbyds_b(i+px,j-1+py))*sin((2*k*pi/num)-pi/2)...
%                 +(G_b(i+px+1,j+py,k)*Vbyds_b(i+1+px,j+py)-G_b(i+px-1,j+py,k)*Vbyds_b(i+px-1,j+py))*cos((2*k*pi/num)-pi/2);
 end

i=1;j=size(G,2);
 for k=1:size(G,3) 
            flux_A=(G_b(i+px,j-1+py,k)*Vbyds_b(i+px,j-1+py)+G_b(i+1+px,j-1+py,k)*Vbyds_b(i+1+px,j-1+py)+G_b(i+1+px,j+py,k)*Vbyds_b(i+1+px,j+py)+G_b(i+px,j+py,k)*Vbyds_b(i+px,j+py))/4; % A
            flux_B=0;%B
            flux_C=0; % C
            flux_D=0; % D
            K(i,j,k)=-J(i,j,k,1)-J(i,j,k,2)-((flux_B-flux_A)*sin_thetaV(k)+(flux_D-flux_C)*cos_thetaV(k));            
            %                K(i,j,k)=(G_b(i+px,j+1+py,k)*Vbyds_b(i+px,j+1+py)-G_b(i+px,j-1+py,k)*Vbyds_b(i+px,j-1+py))*sin((2*k*pi/num)-pi/2)...
%                 +(G_b(i+px+1,j+py,k)*Vbyds_b(i+1+px,j+py)-G_b(i+px-1,j+py,k)*Vbyds_b(i+px-1,j+py))*cos((2*k*pi/num)-pi/2);
 end
end


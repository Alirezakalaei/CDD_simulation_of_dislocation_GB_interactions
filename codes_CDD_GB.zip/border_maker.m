function [border_lines,A,B,C,D] = border_maker(n_vec,b_vec,start_point,magnitude)
b_vec= rotate_vector_line(b_vec, n_vec,pi/4.5);
A=start_point;
B=A+(b_vec)*magnitude;
C=B+(((cross(b_vec,n_vec))/norm(cross(b_vec,n_vec)))*magnitude);
D=C-(b_vec*magnitude);
if A~=D-(((cross(b_vec,n_vec))/norm(cross(b_vec,n_vec)))*magnitude)
    
disp('error')
else 
cener=(A+B+C+D)/4;
border_lines=cell(1,4);
border_lines{1,1}=((A+((B-A)/2))-cener)/norm(((A+((B-A)/2))-cener));
border_lines{1,1}(abs(border_lines{1,1})<10^-15)=0;
border_lines{1,2}=((B+((C-B)/2))-cener)/norm((B+((C-B)/2))-cener);
border_lines{1,2}(abs(border_lines{1,2})<10^-15)=0;
border_lines{1,3}=((C+((D-C)/2))-cener)/norm(((C+((D-C)/2))-cener));
border_lines{1,3}(abs(border_lines{1,3})<10^-15)=0;
border_lines{1,4}=((D+((A-D)/2))-cener)/norm((D+((A-D)/2))-cener);
border_lines{1,4}(abs(border_lines{1,4})<10^-15)=0;



end
end
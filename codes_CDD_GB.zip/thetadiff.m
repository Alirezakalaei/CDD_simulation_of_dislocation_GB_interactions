function [Q]=thetadiff(Q,dt,dVbydxi,dtheta)
% R-K Integration
G=Q;
K1=FDM_rotation(G,dVbydxi,dtheta);
G=Q+K1*(dt/2);
G(G<0)=0;
K2=FDM_rotation(G,dVbydxi,dtheta);
G=Q+K2*(dt/2);
G(G<0)=0;
K3=FDM_rotation(G,dVbydxi,dtheta);
G=Q+K3*dt;
G(G<0)=0;
K4=FDM_rotation(G,dVbydxi,dtheta);
Q=Q+((K1+(2*K2)+(2*K3)+K4)*dt)/6;
% simple FDM
%Q=Q+K1*dt;  
Q(Q<0)=0;
end

function [K]=FDM_rotation(G,dVbydxi,dtheta)
K=zeros(size(G,1),size(G,2),size(G,3));
pz=size(G,3);
[G_b]=periodic_1d(G, size(G,1), size(G,2), size(G,3), pz);
[dVbydxi_b]=periodic_1d(dVbydxi, size(dVbydxi,1), size(dVbydxi,2), size(dVbydxi,3), pz);
for i=1:size(G,1)
    for j=1:size(G,2)
         for k=1:size(G,3)
            flux_A=G_b(i,j,k-1+pz)*dVbydxi_b(i,j,k-1+pz);
            flux_B=G_b(i,j,k+1+pz)*dVbydxi_b(i,j,k+1+pz);
            K(i,j,k)=-(flux_B-flux_A)/(2*dtheta);
         end
    end
end
end
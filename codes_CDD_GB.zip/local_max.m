function [QS] = local_max(converter,QQ,rho_min)
iteration=size(QQ,2);
QS=cell(iteration);
length=size(QQ{1},3);
for ii=1:iteration
QQ{ii}=QQ{ii}*converter;
QS{ii}=zeros(size(QQ{ii},1),size(QQ{ii},2),size(QQ{ii},3));
[QQ{ii}]=periodic_1d(QQ{ii}, size(QQ{ii},1),size(QQ{ii},2), size(QQ{ii},3), size(QQ{ii},3));
 for i=1:size(QQ{ii},1)
        for j=1:size(QQ{ii},2)
            % if sum(QQ{ii}(i,j,:),3)>rho_min
            maximum=max(QQ{ii}(i,j,:),[],'all');
            [M,I]=islocalmax(reshape(QQ{ii}(i,j,:),1,[]),'MinProminence',10^-4,'MinSeparation',8);

            M(length+1)=1;
            M(2*length)=1;
            % I(length+1)=sum(I(length-9:length+1),'all');
            % I(2*length)=sum(I(2*length:length+9),'all');
            M=find(M);
            M(M<1+length|M>2*length)=[];
            QS{ii}(i,j,M-length)=I(M);
            % end
        end
 end
end
%%
%  for i=1:size(QQ,1)
%         for j=1:size(QQ,2)
%             G=[reshape(QQ(i,j,end-69:end),1,[]),reshape(QQ(i,j,:),1,[]),reshape(QQ(i,j,1:70),1,[])];
%               maximum=max(G,[],'all');
%              [M,I]=islocalmax(G,'MinProminence',maximum/1000,'MinSeparation',10);
%              
%             M=find(M);
%             M(M<=70|M>=size(G,2)-69)=[];
%         
%             I=I(M);
%              if size(I)>=1
%    %          I(I<rho_min/converter)=[];
%      %       I((I/nodis)<10^-5)=[];
%              end
%             P(i,j)=sum(I);
%         end
%   end
%%
%   for i=1:size(QQ,1)
%         for j=1:size(QQ,2)
%             G=[reshape(QQ(i,j,end-69:end),1,[]),reshape(QQ(i,j,:),1,[]),reshape(QQ(i,j,1:70),1,[])];
%             [M,I]=islocalmax(G);
%              
%             M=find(M);
%             M(M<=70|M>=size(G,2)-69)=[];
%         
%             I=I(M);
%              if size(I)>=1
%              I((I)<rho_min)=[];
%              end
%             QS(i,j)=sum(I);
%         end
%   end
end

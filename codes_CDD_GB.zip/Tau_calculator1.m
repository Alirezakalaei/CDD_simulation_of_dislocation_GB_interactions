function [taylor_tau] = Tau_calculator1(Q,mio,b,~,~,probability)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
taylor_tau=cell(1,size(Q,2));
Q_all=zeros(size(Q{1},1),size(Q{1},2));
for i=1:size(Q,2)
Q_all=Q_all+sum(Q{i},3);
end
for i=1:size(Q,2)
taylor_tau{i}=.1*mio*b*sqrt(1*(Q_all-sum(Q{i},3)))*(probability);
%taylor_tau{i}=zeros(size(Q{1},2),size(Q{1},1));% this line can be used for
%the condition that we wanna remove taylor stress.
taylor_tau{i}=taylor_tau{i};
end

end

function [sum_J, Sallsum, Pallsum, QQQ, strain, V, stress1, nuc_amount, anni_amount] = comput_sec(QQ, dt, cos_thetaV, sin_thetaV, int_c_lr1, dx, dy, theta, rho_min, tau_app, mobility, dtheta, vel_modif, i, strain, Sallsum, Pallsum, converter, b_vec, n_vec1, taylor, coef1, coef2, sl1, border_lines, interaction_mat, f_l, crit_nuc, pho_nuc, QQ_nuc, max_nuc, d_crit, PP, b, nuc_amount, anni_amount)

    if i == 1
        anni_amount_c = 0;
        nuc_amount_c = 0;
    else
        anni_amount_c = anni_amount(1, i-1);
        nuc_amount_c = nuc_amount(1, i-1);
    end

    %% Velocity Calculator
    tau_int_lr = interaction_lr_mirror_o(PP, int_c_lr1, dx, dy, theta, rho_min, b);
    stress1 = 3 * tau_int_lr + tau_app - taylor;
    stress1(stress1 < 0) = 0;
    
    % This version is not modified close to the grain boundaries.
    Vbydsnm = (stress1) * mobility / (sqrt(2) * dx);
    Vbydsnm((Vbydsnm * dt) > 1) = sqrt(2) * dx / dt;
    Vbydsnm = imgaussfilt(Vbydsnm, 2);

    %% Flux Identifier
    % This function calculates the dislocation density flow out from the grain boundary.
    J = flux_flow_interaction2(QQ, Vbydsnm * sqrt(2) * dx, dx, dy, dtheta, coef1, coef2, sl1, b_vec, border_lines, interaction_mat, dt); 
    J(isnan(J)) = 0;
    J(isinf(J)) = 0;           
    
    %% Numerical Solving
    [QQ{sl1}] = difff7(QQ{sl1}, dt, cos_thetaV, sin_thetaV, J / (sqrt(2) * dx), Vbydsnm);   
    
    % Rotational speed, dV/d(xi), where xi = dislocation line coordinate for each dislocation character k
    [dVbydxi] = theta_diff2(QQ{sl1}, Vbydsnm * sqrt(2) * dx, rho_min, theta, dx, dy);    
    [QQ{sl1}] = thetadiff(QQ{sl1}, dt, dVbydxi, dtheta); 
    
    % Boundary condition enforcement
    QQ{sl1}(isnan(QQ{sl1})) = 0;
    QQ{sl1}(QQ{sl1} < 0) = 0;
    QQ{sl1}(QQ{sl1} > 10^17) = 10^17;

    [QQ{sl1}, anni_amount_c] = annihilation(QQ{sl1}, Vbydsnm * sqrt(2) * dx, dx, dy, dt, b, anni_amount_c);

    %% Nucleation Calculation
    QQ_nu = zeros(size(QQ{sl1}, 1), size(QQ{sl1}, 2), size(QQ{sl1}, 3));
    
    % Define Gaussian standard deviation (controls spread intensity)
    for iii = 1:size(QQ{sl1}, 1)
        for jjj = 1:size(QQ{sl1}, 2)
            if (stress1(iii, jjj) > crit_nuc(iii, jjj))
                % Compute nucleated dislocation density
                QQ_nucc = pho_nuc * dt * ((Vbydsnm(iii, jjj)) * dx * sqrt(2) / f_l(iii, jjj)) * ...
                          exp(-sum(PP(iii, jjj, :), 'all') / max_nuc);
                nuc_amount_c = nuc_amount_c + QQ_nucc;

                % Get spread radius
                spread_radius = ceil(f_l(iii, jjj) / dx);

                % Define directions: [right, left, top, bottom]
                directions = [0, 1; 0, -1; -1, 0; 1, 0]; % (di, dj) pairs
                angle = [1, size(PP, 3)/2, size(PP, 3)/4, 3*size(PP, 3)/4];

                % Compute normalized Gaussian PDF for nucleation distribution
                x_vals = 1:size(PP, 3);
                
                for dir = 1:4
                    di = spread_radius * directions(dir, 1);
                    dj = spread_radius * directions(dir, 2);
                    
                    ni = iii + di;
                    nj = jjj + dj;

                    % Ensure indices are within bounds
                    if ni > 0 && ni <= size(QQ_nu, 1) && nj > 0 && nj <= size(QQ_nu, 2)
                        angle_idx = round(angle(dir)); % Ensure integer index
                        norm_pdf = normpdf(x_vals, angle_idx, 10);
                        norm_pdf = norm_pdf / max(norm_pdf); % Normalize
                        
                        % Apply nucleation to the corresponding direction
                        QQ_nu(ni, nj, :) = QQ_nu(ni, nj, :) + QQ_nucc * reshape(norm_pdf, [1, 1, size(norm_pdf, 2)]);
                    end
                end
            end
        end
    end

    % Update dislocation density
    QQ{sl1} = QQ{sl1} + QQ_nu;
    QQQ = QQ{sl1};
  
    %% Strain Calculation
    strain = strain_finder(strain, PP, Vbydsnm * sqrt(2) * dx, b_vec, n_vec1, dt, dx, J, b);
    strain_eff = (sqrt(2)/3) * sqrt((strain(1,1) - strain(2,2))^2 + (strain(3,3) - strain(2,2))^2 + ...
                 (strain(1,1) - strain(3,3))^2 + 1.5 * (strain(1,3)^2 + strain(2,3)^2 + strain(1,2)^2));
                 
    %% Output Section for Assessing
    nuc_amount(1, i) = nuc_amount_c;
    anni_amount(1, i) = anni_amount_c;
    Sallsum(1, i) = strain_eff;

    % Create the mask
    mask = (Vbydsnm * sqrt(2) * dx > 0.1);

    % Apply the mask and perform the summation
    Pallsum(1, i) = sum(sum(PP .* mask, 3), "all");
    sum_J = sum(J, "all");
    V = Vbydsnm * dx * sqrt(2);
    
end
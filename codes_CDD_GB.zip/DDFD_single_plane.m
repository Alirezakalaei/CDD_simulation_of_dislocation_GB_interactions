function [last_stress, last_strain, sum_J, coef11, coef22, V_all, strain_tensor, converter, ani_amount, nuc_amount, Resolved_S, effective_strain, strain_cell] = DDFD_single_plane(rot_thet, lines)
% Material properties
c_strain = .00003;       % The constant strain rate is selected here
f_strain = .01;          % The simulation will be stopped at this point.
b = 0.286e-9;

for i = 1:size(lines, 1)
    lines{i, 1} = lines{i, 1} * b;
    lines{i, 2} = lines{i, 2} * b;
    lines{i, 3} = lines{i, 3} * b;
end

interaction_dist = 300 * b;
interaction_STD = interaction_dist / .5;
k_par = 10^-13;          % 1*10^0; %0.2*10^-6
mu = 26e9;               % Shear modulus

% n_vec1 = [0 0 1]/sqrt(1);          % slip plane normal
% b_vec1 = {[1 0 0]/sqrt(1), [cos(2*pi/3) sin(2*pi/3) 0]/sqrt(1), [cos(4*pi/3) sin(4*pi/3) 0]/sqrt(1)};
n_vec1 = [1 1 1] / sqrt(3);          % Slip plane normal
b_vec1 = {[-1 0 1]/sqrt(2), -[-1 1 0]/sqrt(2), [0 -1 1]/sqrt(2)};
magnitude = 12000 * b;               % Size of simulation cell 

[border_lines, ~, ~, ~, ~] = border_maker(n_vec1, b_vec1{1, 1}, [magnitude 0 0], magnitude);
[tau_app1, tau_app2, b_vec1, ~, ~, coef1, coef2] = tau_calculator1([.02*mu 0 0; 0 0 0; 0 0 0], b_vec1, n_vec1, b, k_par, border_lines, rot_thet);

coef11 = coef1(1, 1);
coef22 = coef2(1, 1);

% This is for illustrating the starting slip plane.
nu = 0.35;               % Poisson's ratio
mobility = 2*10^-9;      % m/s.pa - Dislocation mobility: v = mobility * tau/mu

% Applied quantities
% tau_app = 0.25;        % RSS on slip system in terms of mu; 

Rc_int = 5000 * b;       % Cutoff radius of dislocation interactions
rho_min = 1e8;           % Minimum density to skip long-range interaction 
a = 8 * b;               % Cai et al.'s singularity removal length scale

% Simulation parameters
dt = 10^-8;              % Time step
T = 150 * dt;            % Time to finish
nxintervals = 61;        % Number of x intervals default 101
nodis = 4;               % Number of dislocations
nthetaintervals = 360;   % Number of nodes over theta-space
dtheta = 2 * pi / nthetaintervals; % Resolution of theta space for density storage
P = 10 * dtheta;         % Standard deviation for gaussian distribution in the theta space.
sdev = 150 * b;          % Standard deviation for the gaussian profile for the dislocation core over spatial domain.  

% mywriter = VideoWriter('longer_annihilation', 'Uncompressed AVI');  % output movie file name and type 
% mywriter.FrameRate = 20;  % frame rate of output movie; default 100

thet_rot_angle = pi / 10; % Rotation around x axis 
phi_rot_angle = pi / 10;  % Rotation around y axis
x_vec1 = [1 0 0];
y_vec1 = [0 1 0];
trabsfer_dist = 500 * b;
cut_off = .15 * magnitude; % The distance to the boundaries that dislocations stop from moving.
coef_keeper1 = coef1;
coef_keeper2 = coef2;
nucle_dist_coef = 3 / 2;   % The radius of a dislocation loop that another one start to nucleate after. 

% Nucleation rate of frank reed source would be specified according to the velocity field.
pho_nuc = 1 * 10^14;
f_l = 200 * b + 1000 * b * rand(nxintervals, nxintervals); % Length of frank-reed sources
crit_nuc = mu * b ./ (f_l / 2); % This is with analytical calculations
% crit_nuc = .05 * ones(nxintervals, nxintervals);
d_crit = 30 * b;
max_nuc = 5 * 10^14;

%% Points extraction
x = linspace(0 * magnitude, 1 * magnitude, nxintervals); % x is a vector of evenly spaced numbers between 0 and magnitude
y = x;
dx = (x(end) - x(1)) / (size(x, 2) - 1); % size(x,2) is the size of vector x
dy = (y(end) - y(1)) / (size(y, 2) - 1); % size(y,2) is the size of vector y
converter = 1; % For the condition of consideration of maximum density we should multiply this number to the nodal densities to have the real density.
% probability_taylor = cubePointProximityProbability(dx, d_crit, 10^8); % monte-carlo for taylor stress

%% Mesh grid (horizontal axis is i, vertical is j)
% coef1(1,:) = coef1(3,:);
% coef2(1,:) = coef2(3,:);
XX = zeros(size(x, 2), size(x, 2));
YY = XX;
ZZ = XX;

for i = 1:size(x, 2)
    for j = 1:size(y, 2)
        XX(i, j) = x(1, i);
        YY(i, j) = y(1, j);
    end
end

meshpoints = zeros((size(x, 2))^2, 2);
k = 1;
for i = 1:size(x, 2)
    for j = 1:size(y, 2)
        meshpoints(k, 1) = XX(i, j);
        meshpoints(k, 2) = YY(i, j);
        k = k + 1;
    end
end
% surf(XX,YY,ZZ)
% hold on
% xlabel('x')
% ylabel('y')


theta = linspace(0, 2 * pi, nthetaintervals);



%% Coarse-graining section
Q = {zeros(size(x, 2), size(y, 2), nthetaintervals), ...
     zeros(size(x, 2), size(y, 2), nthetaintervals), ...
     zeros(size(x, 2), size(y, 2), nthetaintervals)}; % Q(i, j, k) is the density over spatial domain (i,j) and theta-space (k).
QQ = Q;

for j = 1:3
    for i = 1:size(lines, 1) 
        [~, distance, t_a] = distance2curve(lines{i, j}.', meshpoints, 'linear');
        [Q{j}, theta] = discoarse1(distance, t_a, sdev, x, lines{i, j}, dtheta, Q{j}, dx); %% finding the density on Q matrix
    end
    Q{j} = Q{j} / 10;
end

% %% Theta distribution
% PP = cell(1, 3);
% This section is for making dislocation density zero close to grain boundary
% for i = 1:3
%     for j = 1:size(QQ{i}, 1)
%         for k = 1:size(QQ{i}, 1)
%             if XX(j, k) < .1 * magnitude || XX(j, k) > .9 * magnitude || YY(j, k) < .1 * magnitude || YY(j, k) > .9 * magnitude               
%                 Q{i}(j, k, :) = zeros(1, 1, size(QQ{i}, 3));
%             end
%         end
%     end
% end

for i = 1:3
    QQ{i} = cthetacoarse(Q{i}, dtheta, P); % Convert the spread of gaussian profile in the theta-space.
end

%% Nucleation section
% Nucleation would be in the form of a square that nucleates 
array = zeros(1, size(QQ{1}, 3));
% array(1, ceil(rand() * size(QQ{1}, 3))) = 1; ...
array(1, 1 * size(QQ{1}, 3) / 4) = 1;
array(1, 2 * size(QQ{1}, 3) / 4) = 1;
array(1, 3 * size(QQ{1}, 3) / 4) = 1;
array(1, 1) = 1;

QQ_nuc = zeros(size(QQ{1}, 1), size(QQ{1}, 2), size(QQ{1}, 3));
for i = 1:size(QQ{1}, 1)
    for j = 1:size(QQ{1}, 2)
        % if XX(j, j) > .1 * magnitude || XX(j, j) < .9 * magnitude || YY(j, j) > .1 * magnitude || YY(j, j) < .9 * magnitude
        QQ_nuc(i, j, :) = array;
        % end
    end
end

% (Commented out complex boundary nucleation logic omitted for brevity but preserved in structure)
% QQ_nuc = zeros(size(QQ{1}, 1), size(QQ{1}, 2), size(QQ{1}, 3));
% ...

QQ_nuc = cthetacoarse(QQ_nuc, dtheta, P) / 4; % Convert the spread of gaussian profile in the theta-space.

%% Velocity modifier
g_val = 1;
[~, vel_modif, ~] = vel_modifier(XX, YY, ZZ, nxintervals, cut_off, g_val);
g_val2 = 1;
[~, vel_modif_taylor, ~] = vel_modifier(XX, YY, ZZ, nxintervals, 1 * cut_off, g_val2);
% grain_fric = (2 * mu * sqrt(b) / 5) * .1 * (1 - vel_modif);
% grain_fric = (4 * mu * sqrt(b) / 5) * ((1 ./ sqrt(.5 * dx + disf)) - (1 ./ sqrt(.5 * dx + cut_off)));
% grain_fric(isnan(grain_fric)) = 0;

%% Interaction distance calculation points
[interaction_mat] = grain_point_interaction(interaction_dist, interaction_STD, magnitude, dx, nxintervals);

%% Preparing for integration
n_vec_transformed = [0 0 1];
b_vec_transformed = {[cos(0), sin(0), 0], [cos(pi/3), sin(pi/3), 0], [cos(2*pi/3), sin(2*pi/3), 0]};
int_c_lr1 = cell(1, 3);

for i = 1:3
    [int_c_lr1{i}] = interaction_coeff_o(n_vec_transformed, b_vec_transformed{i}, a, mu, nu, dx, dy, Rc_int);
end
% [int_c_lr2] = interaction_coeff(n_vec2, b_vec2, a, mu, nu, dx, dy, Rc_int);

cos_thetaV(:) = cos(theta(:) + pi/4);  % thetaV is dislocation normal from CD axis, theta is dislocation line inclination angle from XX axis
sin_thetaV(:) = sin(theta(:) + pi/4);  % CD axis is 45 deg. from XX axis

% open(mywriter)
% s = figure('units', 'pixels', 'position', [100 0 980 707]);

%% Video writing section
% videoFile = 'random_dislcoation.avi'; % Define the name of the output video file
% writerObj1 = VideoWriter(videoFile); % Create a VideoWriter object
% writerObj1.FrameRate = 30; % Set the frame rate
% open(writerObj1);

%% PDE solving
% Initialize Parameters
tau_app_ref = tau_app1;
[PP] = local_max(converter, QQ, 10^-4);
effective_strain = [];
kp_correction = [];
strain = {[0 0 0; 0 0 0; 0 0 0], [0 0 0; 0 0 0; 0 0 0], [0 0 0; 0 0 0; 0 0 0]};
strain_cell = strain';
Pallsum = {[sum(PP{1}, 'all')], [sum(PP{2}, 'all')], [sum(PP{3}, 'all')]};
ani_amount = Pallsum;
nuc_amount = Pallsum;
Sallsum = {[0], [0], [0]};
Resolved_S = cell(1, 3);
sum_J = zeros(3, T / dt);
V_all = cell(1, 3);
strain_f = 0;         % Total strain at the simulation
strain_r = 0;         % Strain rate at each time step
time = 0;
k_p = 0.3;            % Proportional gain for adaptive feedback control
tau_min = mu / (10^10); % Minimum stress threshold to prevent zero stress

% Main Strain Rate Control Loop
while strain_f <= f_strain
    var = QQ;
    strain_f = strain_f + strain_r;
    fprintf("The strain is %.5f for the angle %.2f\n", strain_f, rot_thet);

    [PP] = local_max(converter, QQ, 10^-4);
    strain_r = 0.000012;  % Initial strain rate estimate
    time = time + 1;
    disp(['Current time step for angle ', num2str(rot_thet, '%.2f'), ': ', num2str(time)]);

    % Strain Rate Correction Loop
    max_iterations = 30;
    iteration_count = 0;
    
    while ((0.95 >= (strain_r / c_strain)) || ((strain_r / c_strain) >= 1.05)) && (strain_r > 0)
        iteration_count = iteration_count + 1;
        if iteration_count > max_iterations
            warning('Strain rate correction loop exceeded max iterations, forcing exit.');
            break;
        end
        if strain_r == 0.000012
            strain = strain_cell(:, end);
        else
            strain_cell(:, end) = [];
            strain = strain_cell(:, end);
        end

        % Adaptive Stress Correction
        if strain_r < 0
            correction_factor = 1.3;
            kp_correction(end+1) = correction_factor;

        elseif strain_r ~= 0.000012
            error = c_strain - strain_r;
            correction_factor = max(min(1 + k_p * error / c_strain, 1.3), 0.7);
            
            % Force stress increase if strain rate is too low
            if abs(strain_r) < 0.5 * c_strain
                correction_factor = max(1.2, correction_factor);
            end
            
            kp_correction(end+1) = correction_factor;

            for i = 1:3
                if numel(Sallsum{i}) > 1
                    Sallsum{i}(end) = [];
                    Pallsum{i}(end) = [];
                end
                tau_app1{1, i} = max(min(tau_app1{1, i} * correction_factor, 4 * mu), tau_min);
                if tau_app1{1, i} > 4 * mu
                    break
                end
                fprintf("The correction factor is %.5f for angle %.2f with ratio of %.5f \n", correction_factor, rot_thet, strain_r / c_strain);
            end
        end

        % Compute Dislocation Evolution for Each Slip System
        for jjj = 1:3
            if tau_app1{1, jjj} == 0
                Sallsum{jjj}(end+1) = 0;
                Pallsum{jjj}(end+1) = Pallsum{jjj}(end);
                continue
            end
            
            [taylor_tau] = Tau_calculator1(PP, mu, b, vel_modif_taylor, dx, 1);

            [sum_J(jjj, time), Sallsum{jjj}, Pallsum{jjj}, QQ{jjj}, strain{jjj}, V_all{jjj}, stress, ...
             nuc_amount{jjj}, ani_amount{jjj}] = comput_sec(var, dt, cos_thetaV, sin_thetaV, ...
             int_c_lr1{jjj}, dx, dy, theta, rho_min, tau_app1{1, jjj}, mobility, dtheta, vel_modif, time, ...
             strain{jjj}, Sallsum{jjj}, Pallsum{jjj}, converter, b_vec_transformed{jjj}, ...
             n_vec_transformed, taylor_tau{jjj}, coef1, coef1, jjj, border_lines, interaction_mat, ...
             nucle_dist_coef * f_l, crit_nuc, pho_nuc, QQ_nuc, max_nuc, d_crit, PP{jjj}, b, ...
             nuc_amount{jjj}, ani_amount{jjj});
        end 

        % Update Strain Matrices
        strain_cell(:, end+1) = strain';
        strain_mat_f = strain_cell{1, end} + strain_cell{2, end} + strain_cell{3, end};
        strain_mat_p = strain_cell{1, end-1} + strain_cell{2, end-1} + strain_cell{3, end-1};
        
        strain_mat_f = (sqrt(2)/3) * sqrt((strain_mat_f(1,1) - strain_mat_f(2,2))^2 + ...
            (strain_mat_f(3,3) - strain_mat_f(2,2))^2 + (strain_mat_f(1,1) - strain_mat_f(3,3))^2 ...
            + 1.5 * (strain_mat_f(1,3)^2 + strain_mat_f(2,3)^2 + strain_mat_f(1,2)^2));
            
        strain_mat_p = (sqrt(2)/3) * sqrt((strain_mat_p(1,1) - strain_mat_p(2,2))^2 + ...
            (strain_mat_p(3,3) - strain_mat_p(2,2))^2 + (strain_mat_p(1,1) - strain_mat_p(3,3))^2 ...
            + 1.5 * (strain_mat_p(1,3)^2 + strain_mat_p(2,3)^2 + strain_mat_p(1,2)^2));

        strain_r = (strain_mat_f - strain_mat_p); % Prevents zero strain rate
        fprintf("The strain rate is %.5f for angle %.2f with stress %.5f \n", strain_r, rot_thet, tau_app1{1, 2} / mu);
    end

    % Store Resolved Shear Stress Data
    for i = 1:3
        if tau_app_ref{i} ~= 0
            Resolved_S{1, i}(end+1) = tau_app1{1, i};
        else
            Resolved_S{1, i}(end+1) = 0;
        end
    end  

    % Store Effective Strain
    effective_strain(1, end+1) = strain_mat_f;
    disp(['current_stress: ', num2str(tau_app1{1, 2} / mu)]);
end

% Save Results
filename = sprintf('little_lower_strain_mu0.08_rot_thet_%.2f.mat', rot_thet);
save(filename, 'Pallsum', 'Sallsum', 'sum_J', 'QQ', 'XX', 'YY', 'ZZ', 'coef1', 'coef2', 'PP', 'V_all', 'ani_amount', 'nuc_amount', 'kp_correction', 'c_strain', 'Resolved_S');

last_stress = Pallsum;
last_strain = Sallsum;
strain_tensor = strain;

end
function [J] = flux_flow_interaction2(QQ,V,dx,dy,dtheta,coef1,coef2,sl1,~,~,interaction_mat,dt)
% this identifier is for rhombus mesh structure and using that for cubic
% one is wront as the counter faces directions are different.
%sl1 specify the slip system that we are calculating the flux for that.1
%flux flow interaction is the distance that slip planes would intersect
%each others
% we should bring all density on other slip planes too.
NN=size(QQ{1},3);
dx=dx*sqrt(2);dy=dy*sqrt(2);
J=zeros(size(QQ{1},1),size(QQ{1},2),size(QQ{1},3),2);%the first one is for x direction and second is for y direction
i=1;% the fluxes from pi/2 to 3pi/2 goes out and others go in.
%coef11=(coef1{sl1,1}(1,1)*sign(dot(b_vec,border_lines{1,4})))+(coef1{sl1,2}(1,1)*sign(dot(b_vec,border_lines{1,4})))+(coef1{sl1,3}(1,1)*sign(dot(b_vec,border_lines{1,4})));
V(V<=0)=0;
V(V>0)=1;
for j=1:size(QQ{1},2)
    if sign(V(i,j))>=0
    for k=1:2*NN/4
        coef11=coef1*[QQ{1}(i,j,k) QQ{2}(i,j,k) QQ{3}(i,j,k) 0 0 0 0 0 0].';
        J(i,j,k,1)=J(i,j,k,1)+(coef11(sl1)*dot([cos(k*dtheta+pi/2),sin(k*dtheta+pi/2),0],[-1 0 0])*interaction_mat(j)*(V(i,j)*dt/dx));
    end
    else
     for k=2*NN/4:NN
         coef11=coef1*[QQ{1}(i,j,k) QQ{2}(i,j,k) QQ{3}(i,j,k) 0 0 0 0 0 0].';
        J(i,j,k,1)=J(i,j,k,1)+(coef11(sl1)*dot([cos(k*dtheta+pi/2),sin(k*dtheta+pi/2),0],[1 0 0])*interaction_mat(j)*(V(i,j)*dt/dx));
     end 
    end
end


i=size(QQ{1},1);% the fluxes from 3pi/2 to 5pi/2 goes out and others go in.
%coef11=(coef1{sl1,1}(1,1)*sign(dot(b_vec,border_lines{1,2})))+(coef1{sl1,2}(1,1)*sign(dot(b_vec,border_lines{1,2})))+(coef1{sl1,3}(1,1)*sign(dot(b_vec,border_lines{1,2})));

for j=1:size(QQ{1},2)
    if sign(V(i,j))>=0
    for k=2*NN/4:4*NN/4
        coef11=coef1*[QQ{1}(i,j,k) QQ{2}(i,j,k) QQ{3}(i,j,k) 0 0 0 0 0 0].';
        J(i,j,k,1)=J(i,j,k,1)+(coef11(sl1)*dot([cos(k*dtheta+pi/2),sin(k*dtheta+pi/2),0],[1 0 0])*interaction_mat(j)*(V(i,j)*dt/dx));
    end
    else
    for k=1:2*NN/4
         coef11=coef1*[QQ{1}(i,j,k) QQ{2}(i,j,k) QQ{3}(i,j,k) 0 0 0 0 0 0].';
        J(i,j,k,1)=J(i,j,k,1)+(coef11(sl1)*dot([cos(k*dtheta+pi/2),sin(k*dtheta+pi/2),0],[-1 0 0])*interaction_mat(j)*(V(i,j)*dt/dx));
    end
    end

end


j=size(QQ{1},2);% the fluxes from 0 to pi goes out and others go in.
%coef22=(coef2{sl1,1}(1,1)*sign(dot(b_vec,border_lines{1,3})))+(coef2{sl1,2}(1,1)*sign(dot(b_vec,border_lines{1,3})))+(coef2{sl1,3}(1,1)*sign(dot(b_vec,border_lines{1,3})));
for i=1:size(QQ{1},1)
 if sign(V(i,j))>=0
    for k=1:NN/4
        coef22=coef2*[QQ{1}(i,j,k) QQ{2}(i,j,k) QQ{3}(i,j,k) 0 0 0 0 0 0].';
        J(i,j,k,2)=J(i,j,k,2)+(coef22(sl1)*dot([cos(k*dtheta+pi/2),sin(k*dtheta+pi/2),0],[0 1 0])*interaction_mat(i)*(V(i,j)*dt/dx));
    end
    for k=3*NN/4:NN
        coef22=coef2*[QQ{1}(i,j,k) QQ{2}(i,j,k) QQ{3}(i,j,k) 0 0 0 0 0 0].';
        J(i,j,k,2)=J(i,j,k,2)+(coef22(sl1)*dot([cos(k*dtheta+pi/2),sin(k*dtheta+pi/2),0],[0 1 0])*interaction_mat(i)*(V(i,j)*dt/dx));
    end
    
 else
   for k=1*NN/4:3*NN/4
        coef22=coef2*[QQ{1}(i,j,k) QQ{2}(i,j,k) QQ{3}(i,j,k) 0 0 0 0 0 0].';       
        J(i,j,k,2)=(J(i,j,k,2))+(coef22(sl1)*dot([cos(k*dtheta+pi/2),sin(k*dtheta+pi/2),0],[0 -1 0])*interaction_mat(i)*(V(i,j)*dt/dx));
   end
 end
end



j=1;% the fluxes from pi to 2*pi goes out and others go in.
% coef22=(coef2{sl1,1}(1,1)*sign(dot(b_vec,border_lines{1,1})))+(coef2{sl1,2}(1,1)*sign(dot(b_vec,border_lines{1,1})))+(coef2{sl1,3}(1,1)*sign(dot(b_vec,border_lines{1,1})));

for i=1:size(QQ{1},1)
    if sign(V(i,j))>=0
    for k=NN/4:3*NN/4
        coef22=coef2*[QQ{1}(i,j,k) QQ{2}(i,j,k) QQ{3}(i,j,k) 0 0 0 0 0 0].';
        J(i,j,k,2)=(J(i,j,k,2))+(coef22(sl1)*dot([cos(k*dtheta+pi/2),sin(k*dtheta+pi/2),0],[0 -1 0])*interaction_mat(i)*(V(i,j)*dt/dx));
    end
    else
    for k=1:1*NN/4
        coef22=coef2*[QQ{1}(i,j,k) QQ{2}(i,j,k) QQ{3}(i,j,k) 0 0 0 0 0 0].';        
        J(i,j,k,2)=(J(i,j,k,2))+(coef22(sl1)*dot([cos(k*dtheta+pi/2),sin(k*dtheta+pi/2),0],[0 1 0])*interaction_mat(i)*(V(i,j)*dt/dx));
    end 
    for k=3*NN/4:NN
        coef22=coef2*[QQ{1}(i,j,k) QQ{2}(i,j,k) QQ{3}(i,j,k) 0 0 0 0 0 0].';        
        J(i,j,k,2)=(J(i,j,k,2))+(coef22(sl1)*dot([cos(k*dtheta+pi/2),sin(k*dtheta+pi/2),0],[0 1 0])*interaction_mat(i)*(V(i,j)*dt/dx));
    end  
    end
end

    
J=abs(J);
end

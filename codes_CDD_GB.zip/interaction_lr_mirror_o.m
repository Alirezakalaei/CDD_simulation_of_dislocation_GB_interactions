function [tau_int_lr]=interaction_lr_mirror_o(G, int_c_lr, dx, dy, theta, rho_min,b)
%int_c_lr2 is the interaction cofficient of the second grain.
%this simulation is designed for mirrior grain boundary.
tau_int_lr=zeros(size(G,1),size(G,2));
nx_co = (size(int_c_lr,1)-1)/2;
ny_co = (size(int_c_lr,2)-1)/2;
rhoG = zeros(3*size(G,1),3*size(G,2));  % GND magnitude at each site
xi = zeros(size(rhoG,1),size(rhoG,2),2);  % direction cosines of GND at each site
px=size(G,1);
py=size(G,2);
% GND
[G]=mirror_2d(G, size(G,1), size(G,2), size(G,3), px, py);
[G]=wall_maker(G, px, py, size(G,3), px, py,20,0);
for i=1:size(G,1)
    for j=1:size(G,2)
        gx = 0;
        gy = 0;
        for k = 1:size(G,3)
            gx = gx + G(i,j,k)*cos(theta(k));   % i (horizontal) axis is the screw axis (reference for dislocation character)
            gy = gy + G(i,j,k)*sin(theta(k));
        end
        rhoG(i,j) = (gx*gx+gy*gy)^0.5;
        if rhoG(i,j)~=0
        xi(i,j,1) = gx/rhoG(i,j);   % projection of GND onto screw axis
        xi(i,j,2) = gy/rhoG(i,j);
        end
    end
end
 
% Establishing long-range interaction RSS and velocity for each field point
% (i,j)
for i=px+1:px+(size(G,1)/3)               % i is along vertical axis, j along horizontal axis
    for j=py+1:py+(size(G,2)/3)
        for ii=1:nx_co*2+1      % summing over neighbours (ii,jj) of field point (i,j) within cutoff
            for jj=1:ny_co*2+1
                is=i+(ii-nx_co-1);   % source point x' gradually moves from left to right of i as ii increases
                js=j+(jj-ny_co-1);
                if 1~=i || j~=j
                    tau_int_lr(i-px, j-py) = tau_int_lr(-px + i, -py + j) + ...
                        (abs((int_c_lr(ii, jj, 1) * xi(is, js, 1)) + (int_c_lr(ii, jj, 2) * xi(is, js, 2)) * rhoG(is, js)) ...
                        *sign(dot([xi(is, js, 1), xi(is, js, 2), 0], [xi(-px + i, -py + j, 1), xi(-px + i, -py + j, 2), 0])));

                end
            end

        end
    end
end
tau_int_lr(:,:)=tau_int_lr(:,:)*dx *dy*300*b*b;% 300b is the depth of the slip plane
end
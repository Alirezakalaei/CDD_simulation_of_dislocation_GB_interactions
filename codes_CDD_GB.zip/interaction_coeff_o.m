function [int_c_lr]=interaction_coeff_o(n_vec, b_vec, a, mu, nu, dx, dy, Rc_int)
    
% Long-range interaction coefficients in Mura's formulation for interaction stress
% simplified for single slip system, i.e. alpha=alpha'
% int_c_lr(ii,jj,h) = n_p*b_q*C_pqrs/mu*C_klij*b_i*e_sjh*G_rk,l for each (x-x’) vector specified by (ii,jj,0) on slip plane
% within cutoff distance, with h specifying the source-dislocation line direction (i.e. d_l(h)).
% a is atomic size that removes singularity in Mura's formula

lom=2*mu*nu/(1-2*nu);

Rc_out=Rc_int; % cutoff radii of dislocation interaction

nx_co=ceil(Rc_out/dx); ny_co=ceil(Rc_out/dy);   % ceil rounds off to next higher integer

int_c_lr=zeros(nx_co*2+1,ny_co*2+1,2);

[e]=epsi; % permutation tensor

% Elastic constants
% C_ijkl = mu*(delta_ik * delta_jl + delta_il * delta_kj) + lambda*(delta_ij * delta_kl)
cbymu = zeros(3:3:3:3);
for i = 1:3
    for j = 1:3
        for k = 1:3
            for l = 1:3
                cbymu(i,j,k,l) = mu*((i==k)*(j==l)+(i==l)*(k==j))+lom*(i==j)*(k==l);
            end
        end
    end
end

%Long range interaction coefficients; eqn 29
for ii=1:nx_co*2+1
    for jj=1:ny_co*2+1
        x=-[dx*(ii-nx_co-1) dy*(jj-ny_co-1) 0];  % x(3) is the (x-x') vector on the slip plane within cutoff, 
                                                % each (x-x') is specified by (ii,jj) on slip plane within cutoff; 
                                                % int_c_lr(ii,jj,h) = n_p*b_q*C_pqrs/mu*C_klij*b_i*e_sjh*G_rk,l
                                                % for each (x-x') within cutoff specified by (ii,jj). 
        R=sqrt(dot(x,x));   
        R_revo=(R^2+(a)^2)^0.5;   % eq. 15 with Cai et al.'s singularity removal 

        for j=1:3
            for s=1:3
                for r=1:3
                    for p=1:3
                        for q=1:2
                            % t1 = n_p * b_q * C_pqrs / mu; 
                            t1=n_vec(p)*b_vec(q)*cbymu(p,q,r,s); 

                            if t1~=0
                                for i=1:2
                                    for k=1:3
                                        for l=1:3
						                    % t2 = b_i * C_ijkl * G_rk,l
                                            t2=-(1/(16*pi*mu*(1-nu)))*b_vec(i)*cbymu(i,j,k,l)* ...
                                                (((r==k)*3*(a)^2*2*(1-nu)/R_revo^5*x(l))+... % extra term from Cai et al. paper
                                                ((3-4*nu)*(r==k)/R_revo^3*x(l))+(3*x(r)*x(k)*x(l)/R_revo^5)- ...
                                                (((r==l)*x(k)+(k==l)*x(r))/R_revo^3));

                                            for h=1:2                                          
                                                int_c_lr(ii,jj,h)=int_c_lr(ii,jj,h)+e(s,j,h)*t2*t1;  
                                            end
                                        end
                                    end
                                end
                            end
                        end
                    end                    
                end
            end
        end
    end
end
'interaction_coeff done'
end
function [G, anni_amount] = annihilation(G,V,dx,dy,dt,b, anni_amount)
% this annihilation is considered as an statical method which the
% charactristic length of our simulation cell is larger than what the
% annihilation phenomena

half=size(G,3)/2;
extra=size(G,3)/10;
% interpolation function making in the following
slope=1/(extra)^2;
int_func=zeros(1,1,2*extra+1);
int_func(1)=0;

for i=1:2*extra
if i<=extra
int_func(1,1,i+1)=int_func(1,1,i)+slope;
else
int_func(1,1,i+1)=int_func(1,1,i)-slope;
end
end

G_p=periodic_1d(G, size(G,1),size(G,2), size(G,3), extra);

% for i=1:size(G,1)
%     for j=1:size(G,2)
%         keeper=zeros(1,size(G,3));
%         for k=extra+1:half+extra   
%             back=sum((G_p(i,j,k-extra:k+extra).*int_func),3);
%             ahead=sum((G_p(i,j,k+half-extra:k+half+extra).*int_func),3);
%         anni_rate=1.3*min(back,ahead)*(2*V(i,j))*dt/(sqrt(dx*dy)); % there is a simplication for the ammount the same velocity for all dislocation characters.
%         keeper(k-extra)=G(1,1,k-extra)-anni_rate;
%         keeper(k+half-extra)=G(1,1,k-extra+half)-anni_rate;
% 
% 
% %             else
% %         anni_rate=min(back,ahead)*dt*sqrt(back*ahead);
% %         G(i,j,k-extra)=G(i,j,k-extra)-10*anni_rate;
% %         G(i,j,k+half-extra)=G(i,j,k+half-extra)-10*anni_rate;        
% %          if G(i,j,k+half-extra)<.01*rho_min && anni_rate>.1*rho_min
% %              G(i,j,k+half-extra)=0;
% %          end
% %          if G(i,j,k-extra)<.01*rho_min && anni_rate>.1*rho_min
% %              G(i,j,k-extra)=0;
% %          end
%         
%         end
        
%         G(i,j,:)=keeper;
%     end
V(V<0)=0;
keeper=zeros(size(G,1),size(G,2),size(G,3));% because of preventing the change in the G function during calculation the data will be kept in keeper
for k=extra+1:half+extra   
            back=sum((G_p(:,:,k-extra:k+extra).*int_func),3);
            ahead=sum((G_p(:,:,k+half-extra:k+half+extra).*int_func),3);

            %anni_rate=.02*min(back,ahead)*ones(size(G,1),size(G,2));
             anni_rate1=(min(back,ahead)*dt/(sqrt(dx*dy))).*V; % there is a simplication for the ammount the same velocity for all dislocation characters.
             anni_rate2= min(back,ahead)*(50*b/dx);
             anni_rate=max(anni_rate1,anni_rate2);
             anni_amount=anni_amount+sum(anni_rate(:),'all');
        keeper(:,:,k-extra)=G(:,:,k-extra)-anni_rate;
        keeper(:,:,k+half-extra)=G(:,:,k-extra+half)-anni_rate;   
end
        
G(:,:,:)=keeper;
    
          


G(G<0)=0;
end